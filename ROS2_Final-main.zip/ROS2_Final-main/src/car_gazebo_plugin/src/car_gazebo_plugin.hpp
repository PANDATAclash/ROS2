#ifndef CAR_GAZEBO_PLUGIN__CAR_GAZEBO_PLUGIN_HPP_
#define CAR_GAZEBO_PLUGIN__CAR_GAZEBO_PLUGIN_HPP_

#include <tf2_ros/transform_broadcaster.h>
#include <ackermann_msgs/msg/ackermann_drive_stamped.hpp>
#include <gazebo/common/PID.hh>
#include <gazebo/common/Plugin.hh>
#include <gazebo/physics/physics.hh>
#include <geometry_msgs/msg/twist.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <sensor_msgs/msg/joy.hpp>
#include <std_msgs/msg/float64.hpp>
#include <std_msgs/msg/int32.hpp>
#include "smartcar_msgs/msg/status.hpp"

double sign_of(double x) {
  if (x > 0) {
    return 1;
  }
  if (x < 0) {
    return -1;
  }
  return 0;
}

class BicycleModel {
  double wheelbase_length;
  double steer_angle;
  double max_steer_angle;

 public:
  BicycleModel(double wheelbase_length, double steer_angle = 0.0, double max_steer_angle = M_PI / 4.0) {
    this->wheelbase_length = wheelbase_length;
    this->steer_angle = steer_angle;
    this->max_steer_angle = max_steer_angle;
  }

  void set_steer_angle(double steer_angle) { 
    if(fabs(steer_angle) > this->max_steer_angle) {
      steer_angle = sign_of(steer_angle) * this->max_steer_angle;
    }
    this->steer_angle = steer_angle; 
  }

  void set_rear_curvature(double k_rear) {
    this->steer_angle = atan(k_rear * this->wheelbase_length);
  }

  double get_rear_curvature() {
    return tan(this->steer_angle) / this->wheelbase_length;
  }

  void set_front_curvature(double k_front) {
    this->steer_angle = asin(this->wheelbase_length * k_front);
  }

  double get_front_curvature() {
    return sin(this->steer_angle) / this->wheelbase_length;
  }

  double get_steer_angle() { return this->steer_angle; }

  BicycleModel get_offset_bicycle(double delta_y) {
    if (this->steer_angle == 0.0) {
      return BicycleModel(wheelbase_length, 0.0);
    }
    BicycleModel new_bike(this->wheelbase_length);
    new_bike.set_rear_curvature(1. /
                                (1. / this->get_rear_curvature() - delta_y));
    return new_bike;
  }
};

class AckermannModel : public BicycleModel {
  double front_wheelbase_width;

 public:
  AckermannModel(double wheelbase_length, double front_wheelbase_width,
                 double steer_angle = 0.0)
      : BicycleModel(wheelbase_length, steer_angle) {
    this->front_wheelbase_width = front_wheelbase_width;
  }

  BicycleModel get_left_bicycle() {
    return this->get_offset_bicycle(this->front_wheelbase_width / 2.);
  }

  BicycleModel get_right_bicycle() {
    return this->get_offset_bicycle(-1. * this->front_wheelbase_width / 2.);
  }
};

namespace car_gazebo_plugin {

class CarGazeboPlugin : public gazebo::ModelPlugin {
 public:
  CarGazeboPlugin();

  void Load(gazebo::physics::ModelPtr model, sdf::ElementPtr sdf);

 private:
  void Update();

  using JointState = sensor_msgs::msg::JointState;
  // using JointCommand = mx_joint_controller_msgs::msg::JointCommand;

  std::string robot_namespace_;

  gazebo::physics::ModelPtr model_;
  gazebo::physics::WorldPtr world_;

  gazebo::common::Time last_sim_time_;
  gazebo::common::Time last_update_time_;
  double update_period_ms_;

  gazebo::event::ConnectionPtr update_connection_;

  std::map<std::string,
           std::pair<gazebo::physics::JointPtr, gazebo::common::PID>>
      joints_;
  std::map<std::string, double> joint_targets_;

  rclcpp::Node::SharedPtr ros_node_;
  rclcpp::Publisher<JointState>::SharedPtr joint_state_pub_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;

  double steer = 0;
  double velocity = 0;

  double pre_steer = 0;
  double pre_rpm = 0;
  const double wheelbase_length = 0.257;
  const double front_wheelbase_width = 0.17;
  const double rear_wheelbase_width = 0.17;
  const double shock_p = 500;
  const double shock_d = 60;
  const double wheel_diameter = 0.064;
  const double max_speed = 2;
  const double max_turn_angle = M_PI/4.0;
  AckermannModel car_model = {0.257, 0.17};

  gazebo::physics::JointControllerPtr jc;
  gazebo::physics::JointPtr fl_str_joint;
  gazebo::physics::JointPtr fr_str_joint;
  gazebo::physics::JointPtr fl_axle_joint;
  gazebo::physics::JointPtr fr_axle_joint;
  gazebo::physics::JointPtr bl_axle_joint;
  gazebo::physics::JointPtr br_axle_joint;
  gazebo::physics::JointPtr fl_shock_joint;
  gazebo::physics::JointPtr fr_shock_joint;
  gazebo::physics::JointPtr bl_shock_joint;
  gazebo::physics::JointPtr br_shock_joint;

  gazebo::common::PID fl_pid, fr_pid, bl_pid, br_pid, fl_shock_pid,
      fr_shock_pid, bl_shock_pid, br_shock_pid;

  rclcpp::Subscription<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr
      ackermann_sub;
  
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr
      cmd_vel_sub;

  
  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr joy_sub;
  rclcpp::Publisher<smartcar_msgs::msg::Status>::SharedPtr status_pub;
  rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr odo_fl_pub;
  rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr odo_fr_pub;
  rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr ackermann_pub;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr pose_pub;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_pub;

  void publish_state() {
    const int ticks_per_revolution = 42;

    std_msgs::msg::Int32 odo_fl;
    odo_fl.data =
        (int)fl_axle_joint->Position() * ticks_per_revolution / (M_2_PI);
    odo_fl_pub->publish(odo_fl);

    std_msgs::msg::Int32 odo_fr;
    odo_fr.data =
        (int)fr_axle_joint->Position() * ticks_per_revolution / (M_2_PI);
    odo_fr_pub->publish(odo_fr);
  }

  void joy_callback(sensor_msgs::msg::Joy::SharedPtr msg) {
    // if(msg->buttons[0] > 0) {
    //   ackermann_msgs::msg::AckermannDriveStamped ad;
    //   ad.drive.steering_angle = msg->axes[0];
    //   ad.drive.speed =
    //       pow(fabs(msg->axes[1]), 2)  * sign_of(msg->axes[1]) * max_speed;
    //   ackermann_pub->publish(ad);
    // }
  }

  void ackermann_callback(
      ackermann_msgs::msg::AckermannDriveStamped::SharedPtr msg) {
    
    car_model.set_steer_angle(msg->drive.steering_angle);

    jc->SetPositionTarget(fl_str_joint->GetScopedName(),
                          car_model.get_left_bicycle().get_steer_angle());

    jc->SetPositionTarget(fr_str_joint->GetScopedName(),
                          car_model.get_right_bicycle().get_steer_angle());

    double curvature = car_model.get_rear_curvature();
    double speed = msg->drive.speed;
    double meters_per_rev = M_PI * wheel_diameter;
    double revs_per_sec = speed / meters_per_rev;
    double rads_per_sec = 2 * M_PI * revs_per_sec;
    if (curvature == 0) {
      jc->SetVelocityTarget(bl_axle_joint->GetScopedName(), rads_per_sec);
      jc->SetVelocityTarget(br_axle_joint->GetScopedName(), rads_per_sec);
    } else {
      double radius = 1. / curvature;
      double left_radius = radius - rear_wheelbase_width / 2.;
      double right_radius = radius + rear_wheelbase_width / 2.;

      jc->SetVelocityTarget(bl_axle_joint->GetScopedName(),
                            rads_per_sec * left_radius / radius);
      jc->SetVelocityTarget(br_axle_joint->GetScopedName(),
                            rads_per_sec * right_radius / radius);
    }
  }

  void twist_callback(geometry_msgs::msg::Twist::SharedPtr msg) {
    ackermann_msgs::msg::AckermannDriveStamped ad;
    ad.drive.speed = msg->linear.x;

    if (abs(msg->linear.x) <= 0.01 && msg->angular.z != 0) {
      ad.drive.speed = 0.2;
      car_model.set_rear_curvature(msg->angular.z / 0.2);
      ad.drive.steering_angle = car_model.get_steer_angle();
    } 
    else if (msg->linear.x == 0 && msg->angular.z == 0) {
      ad.drive.speed = 0;
      ad.drive.steering_angle = 0;
    }
    else {
      car_model.set_rear_curvature(msg->angular.z / msg->linear.x);
      ad.drive.steering_angle = car_model.get_steer_angle();
    }

    ackermann_pub->publish(ad);
  }

 private:
  gazebo::physics::JointPtr get_joint(const char* joint_name) {
    auto joint = model_->GetJoint(joint_name);
    if (joint.get() == 0) {
      RCLCPP_ERROR(ros_node_->get_logger(), "Failed to get_joint %s",
                   joint_name);
    }

    return joint;
  }
};

}  // namespace car_gazebo_plugin

#endif  // CAR_GAZEBO_PLUGIN__CAR_GAZEBO_PLUGIN_HPP_