// generated from rosidl_generator_c/resource/idl.h.em
// with input from ackermann_msgs:msg/AckermannDriveStamped.idl
// generated code does not contain a copyright notice

#ifndef ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_STAMPED_H_
#define ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_STAMPED_H_

#include "ackermann_msgs/msg/detail/ackermann_drive_stamped__struct.h"
#include "ackermann_msgs/msg/detail/ackermann_drive_stamped__functions.h"
#include "ackermann_msgs/msg/detail/ackermann_drive_stamped__type_support.h"

#endif  // ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_STAMPED_H_
