// generated from rosidl_generator_c/resource/idl.h.em
// with input from smartcar_msgs:msg/Status.idl
// generated code does not contain a copyright notice

#ifndef SMARTCAR_MSGS__MSG__STATUS_H_
#define SMARTCAR_MSGS__MSG__STATUS_H_

#include "smartcar_msgs/msg/detail/status__struct.h"
#include "smartcar_msgs/msg/detail/status__functions.h"
#include "smartcar_msgs/msg/detail/status__type_support.h"

#endif  // SMARTCAR_MSGS__MSG__STATUS_H_
